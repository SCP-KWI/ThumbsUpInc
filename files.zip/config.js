// Thumbs Up Inc. - Game Configuration
// Phase 1: MVP with Organic Content + Ads only

const GAME_CONFIG = {
  // Timer settings
  GAME_DURATION: 600, // 10 minutes in seconds
  UPDATE_INTERVAL: 100, // Game loop runs every 100ms
  
  // Engagement mechanics
  ENGAGEMENT_DECAY_RATE: 0.2, // -2% per 10 seconds = 0.2% per second
  ENGAGEMENT_DEATH_THRESHOLD: 20, // Game over if engagement drops below 20%
  ENGAGEMENT_WARNING_THRESHOLD: 30, // Visual warning threshold
  
  // Happiness/Anger bonuses to engagement
  HAPPINESS_ENGAGEMENT_BONUS: 0.05, // +0.5% engagement per 10 happiness = 0.05 per 1 happiness
  ANGER_ENGAGEMENT_BONUS: 0.1, // +1% engagement per 10 anger = 0.1 per 1 anger
  
  // Feed settings
  POST_GENERATION_INTERVAL: 2000, // Generate new post every 2 seconds
  FEED_SCROLL_SPEED: 50, // Pixels per second
  MAX_POSTS_VISIBLE: 10, // Keep last 10 posts in DOM
  
  // UI thresholds for color coding
  METER_HIGH_THRESHOLD: 60, // Green
  METER_MEDIUM_THRESHOLD: 30, // Yellow
  // Below medium = Red
  
  // Starting values
  STARTING_ENGAGEMENT: 100,
  STARTING_HAPPINESS: 100,
  STARTING_ANGER: 0,
  STARTING_MONEY: 0
};

const CONTENT_TYPES = {
  organic: {
    name: 'Organic Content',
    nameDE: 'Organische Inhalte',
    revenue: 0,
    happiness: 2,
    anger: 0,
    engagement: 3,
    color: '#5B8DC7', // Muted blue
    unlockLevel: 1,
    description: 'Non-monetized posts from friends',
    descriptionDE: 'Nicht-monetisierte Posts von Freunden'
  },
  ads: {
    name: 'Ads',
    nameDE: 'Werbung',
    revenue: 2,
    happiness: -5,
    anger: 0,
    engagement: 0,
    color: '#D4A76A', // Muted gold
    unlockLevel: 1,
    description: 'Standard display advertisements',
    descriptionDE: 'Standard Werbeanzeigen'
  },
  sponsored: {
    name: 'Sponsored Content',
    nameDE: 'Gesponserte Inhalte',
    revenue: 4,
    happiness: -3,
    anger: 0,
    engagement: 5,
    color: '#9B7EBD', // Muted purple
    unlockLevel: 2,
    description: 'Native advertising disguised as organic posts',
    descriptionDE: 'Native Advertising getarnt als organische Posts'
  },
  influencer: {
    name: 'Influencer Partnerships',
    nameDE: 'Influencer-Partnerschaften',
    revenue: 4,
    happiness: -2,
    anger: 0,
    engagement: 8,
    color: '#E89AC7', // Muted pink
    unlockLevel: 3,
    description: 'Paid celebrity/influencer endorsements',
    descriptionDE: 'Bezahlte Promi/Influencer-Empfehlungen'
  },
  viralOrganic: {
    name: 'Viral Organic Content',
    nameDE: 'Virale organische Inhalte',
    revenue: 0,
    happiness: 10,
    anger: 0,
    engagement: 15,
    color: '#7FBF7F', // Muted green/gold
    unlockLevel: 3,
    description: 'Highly shareable genuine content',
    descriptionDE: 'Sehr teilbare echte Inhalte'
  },
  propaganda: {
    name: 'Propaganda',
    nameDE: 'Propaganda',
    revenue: 6,
    happiness: -8,
    anger: 15,
    engagement: 12,
    color: '#C85A54', // Muted red
    unlockLevel: 4,
    description: 'Political/ideological content paid by lobbying groups',
    descriptionDE: 'Politische/ideologische Inhalte bezahlt von Lobbygruppen'
  },
  clickbait: {
    name: 'Clickbait',
    nameDE: 'Clickbait',
    revenue: 3,
    happiness: -6,
    anger: 5,
    engagement: 10,
    color: '#E8A87C', // Muted orange
    unlockLevel: 4,
    description: 'Sensationalized, misleading headlines',
    descriptionDE: 'Sensationelle, irreführende Schlagzeilen'
  },
  scams: {
    name: 'Scams',
    nameDE: 'Betrug',
    revenue: 15,
    happiness: -15,
    anger: 0,
    engagement: 0,
    color: '#8B4646', // Dark muted red
    unlockLevel: 5,
    scamRisk: 0.05, // 5% chance per scam post
    description: 'Fraudulent offers, fake products, phishing',
    descriptionDE: 'BetrÃ¼gerische Angebote, gefälschte Produkte, Phishing'
  }
};

// Avatar states based on metrics
const AVATAR_STATES = {
  // Facial expressions based on happiness
  expression: {
    happy: { min: 60, emoji: '😊' },
    neutral: { min: 30, emoji: '😐' },
    sad: { min: 0, emoji: '😢' }
  },
  // Distance from phone based on engagement
  distance: {
    close: { min: 60, label: 'Very engaged' },
    medium: { min: 30, label: 'Moderately engaged' },
    far: { min: 0, label: 'Losing interest' }
  }
};

// Level unlock system
const LEVELS = [
  {
    number: 1,
    name: 'The Organic Era',
    nameDE: 'Die organische Ära',
    timeThreshold: 0,
    moneyThreshold: 0,
    unlocks: ['organic', 'ads'],
    popupEN: "Welcome to Thumbs Up Inc.! Right now, users see posts from friends and family. You earn $0. Investors are getting impatient...",
    popupDE: "Willkommen bei Thumbs Up Inc.! Momentan sehen Nutzer nur Posts von Freunden und Familie. Du verdienst $0. Die Investoren werden ungeduldig..."
  },
  {
    number: 2,
    name: 'Native Advertising',
    nameDE: 'Native Advertising',
    timeThreshold: 90, // 1:30
    moneyThreshold: 50,
    unlocks: ['sponsored'],
    popupEN: "Great! Advertisers want to blend in. Sponsored Content looks like real posts but pays you money. Users might not even notice... at first.",
    popupDE: "Super! Werbetreibende wollen sich einfügen. Gesponserte Inhalte sehen aus wie echte Posts, bringen dir aber Geld. Die Nutzer merken es vielleicht nicht mal... am Anfang."
  },
  {
    number: 3,
    name: 'The Influencer Economy',
    nameDE: 'Die Influencer-Wirtschaft',
    timeThreshold: 180, // 3:00
    moneyThreshold: 200,
    unlocks: ['influencer', 'viralOrganic'],
    popupEN: "Influencers have massive followings. Pay them to promote products. Their fans will engage like crazy! We've also improved our algorithm to find viral content - but it doesn't pay...",
    popupDE: "Influencer haben riesige Followerzahlen. Bezahle sie, um Produkte zu bewerben. Ihre Fans werden richtig engagiert! Wir haben auch unseren Algorithmus verbessert, um virale Inhalte zu finden - aber die zahlen nichts..."
  },
  {
    number: 4,
    name: 'The Outrage Machine',
    nameDE: 'Die Empörungsmaschine',
    timeThreshold: 300, // 5:00
    moneyThreshold: 500,
    unlocks: ['propaganda', 'clickbait'],
    popupEN: "Political groups will pay BIG money to influence opinions. Warning: Users might get angry... but angry users are engaged users.",
    popupDE: "Politische Gruppen zahlen RICHTIG Geld, um Meinungen zu beeinflussen. Warnung: Nutzer könnten wütend werden... aber wütende Nutzer sind engagierte Nutzer."
  },
  {
    number: 5,
    name: 'Maximum Extraction',
    nameDE: 'Maximale Ausbeutung',
    timeThreshold: 420, // 7:00
    moneyThreshold: 1000,
    unlocks: ['scams'],
    popupEN: "Shady operators want to reach your users. It's risky - if users catch on, they might leave - but the money is incredible.",
    popupDE: "Zwielichtige Anbieter wollen deine Nutzer erreichen. Es ist riskant - wenn Nutzer es merken, verlassen sie vielleicht die Plattform - aber das Geld ist unglaublich."
  }
];

// Export for use in other files
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { GAME_CONFIG, CONTENT_TYPES, AVATAR_STATES, LEVELS };
}
